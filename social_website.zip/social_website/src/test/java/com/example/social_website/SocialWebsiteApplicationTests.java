package com.example.social_website;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
